Removing Digital Signatures for Imaginators (Cemu)

Move the "patch_remove_signature" folder into the "Cemu\graphicPacks" directory.

Example of the file paths after placement:

"Cemu\graphicPacks\patch_remove_signature\patch_remove_signature.asm"
"Cemu\graphicPacks\patch_remove_signature\rules.txt"

Special thanks to Maff (@spyroskingdom) and ItsSecretNate (@itssecretnate) for making this mod possible.